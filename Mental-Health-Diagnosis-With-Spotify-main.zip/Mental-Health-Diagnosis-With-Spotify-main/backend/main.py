from flask import Flask, jsonify
import pandas as pd
import pickle
import os

app = Flask(__name__)

ocdModel = pickle.load(open("models/OCD.pkl", 'rb'))
insomniaModel = pickle.load(open("models/Insomnia.pkl", 'rb'))
anxietyModel = pickle.load(open("models/Anxiety.pkl", 'rb'))
depressionModel = pickle.load(open("models/Depression.pkl", 'rb'))


@app.route('/')
def index():
    return jsonify({"Choo Choo": "Welcome to your Flask app 🚅"})


@app.route('/predict/<BPM>')
def book(BPM):
    value = pd.DataFrame({
        'BPM': [BPM]
    })

    o = ocdModel.predict(value)[0]
    i = insomniaModel.predict(value)[0]
    a = anxietyModel.predict(value)[0]
    d = depressionModel.predict(value)[0]

    print(o)

    pred = {
        "ocd": str(o),
        "insomnia": str(i),
        "anxiety": str(a),
        "depression": str(d),
    }

    return jsonify(pred)


if __name__ == '__main__':
    app.run(debug=True, port=os.getenv("PORT", default=5000))


# if __name__ == '__main__':
#     app.run()

# if __name__ == '__main__':
#     app.run(debug=True, port=os.getenv("PORT", default=5000))
