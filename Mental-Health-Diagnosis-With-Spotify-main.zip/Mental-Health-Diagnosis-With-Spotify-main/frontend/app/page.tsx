import Image from "next/image";
import { getServerSession } from "next-auth/next";
import SpotifyProvider from "next-auth/providers/spotify";
import SpotifyWebApi from "spotify-web-api-node";
import { SessionProvider, getSession, signIn, useSession } from "next-auth/react";
import spotifyApi from "@/lib/spotify";
import { Suspense } from "react";
import { authOptions } from "./api/auth/[...nextauth]/route";
import { Button } from "@/components/ui/button";
import { Key, UserCircle } from "lucide-react";
import Header from "@/components/header";
import { ScrollArea } from "@/components/ui/scroll-area";

export default async function Home() {
	const session = await getServerSession(authOptions);

	let tracks,
		avgBPM = 0,
		user,
		limit = 10,
		prediction: any = {};

	try {
		if (session) {
			user = session.user;

			const res = await spotifyApi.getMyRecentlyPlayedTracks({
				limit: limit,
			});

			tracks = res.body.items;
			let ids: string[] = [];

			tracks.forEach((value) => {
				ids.push(value.track.id);
			});

			const audioRes = await spotifyApi.getAudioFeaturesForTracks(ids);

			let sumBPM = 0;

			audioRes.body.audio_features.forEach((value) => {
				sumBPM += value.tempo;
			});

			avgBPM = sumBPM / limit;

			avgBPM = avgBPM;

			const predRes = await fetch(`https://deprestify.onrender.com/predict/${avgBPM}`);
			prediction = await predRes.json();
		}
  } catch (error) {
  }
  
	return (
		<main>
			<Header />
			<section className="grid grid-cols-1 gap-4 p-4 md:grid-cols-2">
				{/* profile */}
				<Suspense>
					<div className="relative flex h-[25em] flex-row items-end gap-2 border rounded-md overflow-clip">
						<div className="absolute z-10 flex flex-col justify-end w-full h-full bg-black opacity-50"></div>
						<div className="z-20 flex flex-row items-center w-full gap-6 px-6 py-2 bg-white rounded shadow-md md:w-fit md:m-2">
							<UserCircle className="w-8 h-8" />
							<div className="">
								<p className="font-medium">{user?.name}</p>
								<p>{user?.email}</p>
							</div>
						</div>
						{user && user.image ? <Image src={user.image} alt={"pfp"} fill style={{ objectFit: "cover" }} /> : ""}
					</div>
				</Suspense>
				{/* History  */}
				<Suspense>
					<ScrollArea className="h-[25em] w-full rounded-md border p-4">
						<p className="font-medium underline">
							Listening History ({limit} tracks | {avgBPM.toFixed(4)} average BPM)
						</p>
						<div className="flex flex-col gap-4 py-4">
							{!tracks
								? "None"
								: tracks.map((value, key) => (
										<div key={key} className="flex flex-row gap-2">
											<Image src={value.track.album.images[0].url} className="rounded" alt={"pfp"} width={80} height={80} />
											{value.track.name}
											<br />
											{value.track.artists[0].name}
										</div>
								  ))}
						</div>
					</ScrollArea>
				</Suspense>
				{/* Prediction */}
				<Suspense>
					<section className="p-4 border rounded-md ">
						<p className="font-medium underline">Prediction</p>
						<div className="grid gap-2 py-4 md:grid-cols-4">
							<div
								className={`flex flex-col p-10 rounded shadow text-center ${
									prediction && prediction.anxiety == "True" ? "bg-blue-200" : ""
								}`}>
								<span>Anxiety</span>
								<span className="text-[2em] font-medium">{!prediction ? "None" : prediction.anxiety}</span>
							</div>
							<div
								className={`flex flex-col p-10 rounded shadow text-center ${
									prediction && prediction.ocd == "True" ? "bg-blue-200" : ""
								}`}>
								<span>OCD</span>
								<span className="text-[2em] font-medium">{!prediction ? "None" : prediction.ocd}</span>
							</div>
							<div
								className={`flex flex-col p-10 rounded shadow text-center ${
									prediction && prediction.insomnia == "True" ? "bg-blue-200" : ""
								}`}>
								<span>Insomnia</span>
								<span className="text-[2em] font-medium">{!prediction ? "None" : prediction.insomnia}</span>
							</div>
							<div
								className={`flex flex-col p-10 rounded shadow text-center ${
									prediction && prediction.depression == "True" ? "bg-blue-200" : ""
								}`}>
								<span>Depression</span>
								<span className="text-[2em] font-medium">{!prediction ? "None" : prediction.depression}</span>
							</div>
						</div>
					</section>
				</Suspense>
				{/* hotline */}
				<section className="p-4 border rounded-md ">
					<p className="font-medium underline">Befrienders Kuala Lumpur</p>
					<p className="text-[2em] md:text-[5em] font-semibold">03-7627 2929</p>
				</section>
			</section>
			{/* <section className="px-4 pt-10">
        <h1 className="text-center text-[4em] font-medium italic">Prediction</h1>
				<Suspense>
					<section className="mt-10">
						<p>Prediction for an average BPM of {avgBPM}</p>
						<div className="grid grid-cols-4 gap-2">
							<div className="p-10 rounded shadow">Anxiety: {!prediction ? "None" : prediction.anxiety}</div>
							<div className="p-10 rounded shadow">OCD: {!prediction ? "None" : prediction.ocd}</div>
							<div className="p-10 rounded shadow">Insomnia: {!prediction ? "None" : prediction.insomnia}</div>
							<div className="p-10 rounded shadow">Depression: {!prediction ? "None" : prediction.depression}</div>
						</div>
					</section>
				</Suspense>
			</section> */}
		</main>
	);
}
