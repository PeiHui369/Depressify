import SpotifyProvider from "next-auth/providers/spotify";
import NextAuth, { NextAuthOptions } from "next-auth";
import SpotifyWebApi from "spotify-web-api-node";
import spotifyApi, { LOGIN_URL } from "@/lib/spotify";
import { TokenClass } from "typescript";

const clientId = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID!;
const clientSecret = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_SECRET!;
const redirectUri = process.env.NEXT_PUBLIC_SPOTIFY_REDIRECT_URI!;

export const authOptions: NextAuthOptions = {
	providers: [
		SpotifyProvider({
			clientId: clientId,
			clientSecret: clientSecret,
			authorization: LOGIN_URL,
		}),
	],
	secret: process.env.NEXTAUTH_SECRET,
	callbacks: {
		async jwt({ token, account }) {
			if (account) {
				token = Object.assign({}, token, { access_token: account.access_token });
				spotifyApi.setAccessToken(account.access_token!);
				spotifyApi.setRefreshToken(account.refresh_token!);
			}

			return token;
		},
		async session({ session, token }) {
			if (session) {
				let accToken: any = token.access_token;

				if (Date.now() > new Date(session.expires).getUTCMilliseconds()) {
					session.user.token = accToken;
					spotifyApi.setAccessToken(accToken);
				}
			}

			return session;
		},
	},
};

const handler = NextAuth(authOptions);

export { handler as GET, handler as POST };
