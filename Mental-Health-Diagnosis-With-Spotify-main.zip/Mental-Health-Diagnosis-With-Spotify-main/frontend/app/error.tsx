"use client"; // Error components must be Client Components

import { Button } from "@/components/ui/button";
import { Server } from "lucide-react";
import { useEffect } from "react";

export default function Error({ error, reset }: { error: Error; reset: () => void }) {
	useEffect(() => {
		// Log the error to an error reporting service
		console.error(error);
	}, [error]);

	return (
		<div className="flex flex-col items-center justify-center w-screen h-screen bg-red-100">
			<div className="p-10">
				<Server className="w-[10em] h-[10em] pb-4" />
				<h1 className="text-[2em] md:text-[3em] font-semibold">Rebooting server...</h1>
				<p className="text-[1em] md:text-[1.5em] pb-4">
					Due to API restrictions, we put our server to sleep when there is inactivity for some period of time. Please ry again in
					a minute.
					<br />
				</p>
				<Button
					size={"lg"}
					className="w-full"
					onClick={
						// Attempt to recover by trying to re-render the segment
						() => reset()
					}>
					Try again
				</Button>
			</div>
		</div>
	);
}
