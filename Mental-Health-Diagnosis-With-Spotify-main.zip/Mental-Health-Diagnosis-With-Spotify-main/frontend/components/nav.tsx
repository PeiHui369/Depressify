"use client";
import React from "react";
import { Button } from "./ui/button";
import { Key } from "lucide-react";
import Link from "next/link";
import { LoginButton } from "./buttons.component";
import { signIn, signOut } from "next-auth/react";

export default function Nav() {
	return (
		<div className="flex flex-row items-center justify-between p-4 border-b-[1px]">
			<span className="font-bold">Deprestify</span>
			<Button onClick={() => signIn()}>
				<Key className="w-4 h-4 mr-2" /> Login with Spotify
			</Button>
		</div>
	);
}
