"use client";
import React from "react";
import { Button } from "./ui/button";
import { Key } from "lucide-react";
import { signIn } from "next-auth/react";
import Image from "next/image";

export default function Header() {
	return (
		<section className="bg-green-300 h-[35vh] flex flex-col items-center justify-center">
			<div className="flex flex-col items-start gap-4 md:gap-8 md:flex-row">
				<div className="h-[4em] md:h-[8em] aspect-square relative rounded overflow-clip">
					<Image src={"/logo.png"} alt={"logo"} fill />
				</div>
				<div>
					<h1 className="text-lg md:text-[3em] font-semibold">Deprestify</h1>
					<p className="text-base md:text-[2em] md:pt-6">Unlocking Minds Through Melodies</p>
					<Button onClick={() => signIn()} className="mt-8">
						<Key className="w-4 h-4 mr-2" /> Login with Spotify
					</Button>
				</div>
			</div>
		</section>
	);
}
