import SpotifyWebApi from "spotify-web-api-node";

const scopes: any = [
	"ugc-image-upload",
	"user-read-playback-state",
	"user-modify-playback-state",
	"user-read-currently-playing",
	"streaming",
	"app-remote-control",
	"user-read-email",
	"user-read-private",
	"playlist-read-collaborative",
	"playlist-modify-public",
	"playlist-read-private",
	"playlist-modify-private",
	"user-library-modify",
	"user-library-read",
	"user-top-read",
	"user-read-playback-position",
	"user-read-recently-played",
	"user-follow-read",
	"user-follow-modify",
];

const clientId = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_ID!;
const clientSecret = process.env.NEXT_PUBLIC_SPOTIFY_CLIENT_SECRET!;
const redirectUri = process.env.NEXT_PUBLIC_SPOTIFY_REDIRECT_URI!;
const state = "a";

const spotifyApi = new SpotifyWebApi({
	redirectUri: redirectUri,
	clientId: clientId,
	clientSecret: clientSecret,
});

const LOGIN_URL = spotifyApi.createAuthorizeURL(scopes, state);

const params = {
	scopes: scopes,
};

// const LOGIN_URL = `https://accounts.spotify.com/authorize?${new URLSearchParams(params).toString}`;



export default spotifyApi;
export { LOGIN_URL };
